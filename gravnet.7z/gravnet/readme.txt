gravnet.f90: gravity network adjustment program
compare.f90: compared old and new gravity values and test changes
taiwan.obs: file of relative gravity observations
six.fix: gravity values at six fixed stations
period.dat:; periods of LCR instruments
exp.bat: batch job for five cases